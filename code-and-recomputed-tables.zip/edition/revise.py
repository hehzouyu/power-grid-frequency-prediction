"""基于独立 MATLAB 复算表重写稿件。对锚点做唯一性检查，避免静默漏改。"""
from pathlib import Path
import re
import csv
import json
import pandas as pd
from seal_revision import count_text, move_sentence

D=Path(__file__).resolve().parent
V=D.parent/'2026-11-21-项目总稿-v2'
R=D/'复算表'
names={'gate':'门控滚动','quadratic':'二次滚动','persistence':'持续性滚动','endpoint':'端点滚动',
       'ecgr':'固定ECGR','gate_final_only':'仅末窗门控','segmented':'分段滚动',
       'quadratic_fixed':'0.50 s二次','quadratic_stratified':'二次滚动（分级）','gate_stratified':'门控滚动（分级）'}
scopes={'mixed':'主条件混合','clean':'干净','white40':'白40 dB','white30':'白30 dB','white20':'白20 dB','ar30':'AR(1)30 dB','jump':'噪声突变'}
A=pd.read_csv(R/'全部绝对结果.csv')
E=pd.read_csv(R/'全部配对区间.csv')
G=pd.read_csv(R/'原滚动命中集合.csv').set_index('Group')
C=pd.read_csv(R/'干净条件对称分解.csv').iloc[0]
C4=pd.read_csv(R/'干净条件阈值交换.csv')
H=pd.read_csv(R/'同实际虚警事后诊断.csv')
Y=pd.read_csv(R/'标签19至20秒核对.csv')
Q=pd.read_csv(R/'逐窗选择比例.csv')

def txt(p): return p.read_text(encoding='utf-8-sig')
def save(name,s): (D/name).write_text(s,encoding='utf-8')
def once(s,a,b):
    if s.count(a)!=1: raise ValueError(f'修改锚点应唯一: {a[:110]}')
    return s.replace(a,b,1)
def replace_par(s,prefix,body):
    a=[x for x in s.splitlines() if x.startswith(prefix)]
    assert len(a)==1,prefix
    return once(s,a[0],body)
def add(s,anchor,body): return once(s,anchor,body+'\n\n'+anchor)
def al(scope,policy,t=.1): return A[(A.Scope==scope)&(A.TargetFAR==t)&(A.Policy==policy)].iloc[0]
def ep(scope,p='gate',q='quadratic',t=.1):
    return E[(E.Scope==scope)&(E.Policy==p)&(E.Comparator==q)&(E.TargetFAR==t)].iloc[0]
def diag(name,far): return H[(H.Dataset==name)&(H.ActualFAR_pct==far)].iloc[0]
def num(x): return f'{x:.2f}'.replace('-','−')
def bounds(lo,hi): return f'[{num(lo)}, {num(hi)}]'
def pair(lo,hi,z): return bounds(z[lo],z[hi])
def rate(x): return num(x)+r'\%'
def val(x,d=0): return '--' if pd.isna(x) else f'{x:.{d}f}'
def row(parts): return ' & '.join(str(x) for x in parts)+r' \\'
def table(caption,label,columns,heads,rows,long=False):
    """长表每页重印表头。图表计数由LaTeX原生计数器产生。"""
    if long:
        return '\n'.join([r'\begingroup\scriptsize\setlength{\tabcolsep}{3pt}',r'\begin{longtable}{'+columns+'}',
                          r'\caption{'+caption+r'}\label{'+label+r'}\\',
                          r'\toprule',row(heads),r'\midrule\endfirsthead',
                          r'\toprule',row(heads),r'\midrule\endhead',
                          r'\bottomrule\endfoot',*rows,r'\end{longtable}\endgroup'])
    return '\n'.join([r'\begin{table}[!htbp]\centering\small\setlength{\tabcolsep}{4pt}',
                      r'\caption{'+caption+r'}\label{'+label+r'}',
                      r'\begin{tabular}{'+columns+'}',r'\toprule',row(heads),r'\midrule',*rows,
                      r'\bottomrule\end{tabular}\end{table}'])
def fig(path,cap,label,w='.84'):
    return r'\begin{center}\includegraphics[width='+w+r'\linewidth]{'+path+r'}\captionof{figure}{'+cap+r'}\label{'+label+r'}\end{center}'

g,q,p=[al('mixed',x) for x in ('gate','quadratic','persistence')]
g5,q5=[al('mixed',x,.05) for x in ('gate','quadratic')]
e,j,b,st=[ep('mixed'),ep('jump'),ep('mixed',q='persistence'),ep('mixed',p='gate_stratified',q='quadratic_stratified')]
a5=ep('mixed',t=.05)
assert (g.Hits,q.Hits,g.FalseAlarms,q.FalseAlarms,g.Variants)==(1622,1012,1076,912,12000)
assert g.RiskVariants+g.NonriskVariants==g.Variants
assert round(e.FARHigh_pp,2)==2.58 and e.FARHigh_pp>2
assert len(Y)==8 and Y.Changed.eq(0).all()
assert (G.loc['early','RollingHits'],G.loc['late','RollingHits'],G.loc['fixed_only','Events'])==(98,174,15)

def edit_main():
    s=txt(V/'frequency-project.tex')
    s=once(s,r'\usepackage[hidelinks]{hyperref}',r'\usepackage{xr}'+'\n'+r'\usepackage[hidelinks]{hyperref}'+'\n'+r'\externaldocument[sup:]{frequency-project-supplement}')
    s=once(s,'ECGR接入滚动后增加及时命中，主试验虚警保护未通过。','ECGR质量门控接入滚动后增加及时命中，10\\%主比较的虚警保护未通过。')
    s=replace_par(s,'本文首先用严格的',r'''本文考察有限频率量测在幅值预测和时序告警中的作用。首先，采用严格截止和后缀标签，按全局最低点形成时序分组；分析端点冗余、弦线残差与调频动态，并以独立近端点配对检验增量预测信息。其次，构造端点约束协方差加权弦线残差估计（ECGR）与固定截止质量门控，分别评价干净收益、方向判对及噪声尾部。再次，用原滚动预测器研究提前决策的时序收益，并以未越限事件进行质量分级校准。最后，在另一批独立聚合场景上检验固定质量门控接入四个滚动决策窗的效果。两项滚动研究各用其自身冻结模型和场景；双侧区间、单侧下界及多机数值压力检验给出适用边界。''')
    s=once(s,'首尾量测误差被多个残差共享',r'协方差加权最小二乘的基本构造见文献\cite{aitken1936}。首尾量测误差被多个残差共享')
    s=once(s,'首尾量测误差被多个残差共享，因此原频率白噪声也会在残差中产生相关性。',
              '首尾量测误差被多个残差共享，因此原频率白噪声也会在残差中产生相关性。保留两端点时，全维弦线残差与原窗可相互重构。预测收益来自施加约束及收缩的整体估计；现有实验未单独识别白化、反对称项和收缩各项的必要性。')
    s=replace_par(s,'针对固定截止ECGR门控',r'''\subsection{ECGR质量门控的滚动迁移}\label{sec:roll-transfer}
四个决策时刻0.20、0.30、0.40、0.50 s分别有11、16、21、26点。设某窗有$n$点，$u_j=j/(n-1)$。两个端点与$n-2$个内部点构成弦线矩阵$L$，相应行是$[-(1-u_j),\,\boldsymbol e_j^\mathsf T,\,-u_j]$。$B$在内部点取$u_j(1-u_j)$及$u_j(1-u_j)(2u_j-1)$，$S=(I+\operatorname{Toeplitz}(0.65^{|i-j|}))/2$，$C$为$LSL^\mathsf T$的下三角Cholesky因子。ECGR仍用$\lambda=4$和固定截止原开发尺度$v=7.3831\times10^{-5}$ Hz$^2$；各窗按$n-4$个残差自由度估计窗内尺度，未按窗重估$v$。预测器按窗分别在原1200组开发轨迹上拟合，每个表示用100棵、最大深度3的梯度提升树；特征以Hz及相应斜率单位直接输入，无独立标准化器。

同一次扰动的50点扰动前量测在四窗共用；幅度分母和三阶差分按当前可见窗计算，因此$Q$可随窗长改变。原门槛0.0025、0.016按窗使用，低值选ECGR、中间选二次、高值或不可用退回端点。800个新事件用于告警校准，另以2400个独立事件确认。开发档案截至扰动后19 s，校准和确认截到20 s，均预测窗后的最低频率。对校准和确认的存档参数回放原积分器，经逐窗验证20 s标签后，截短到19 s未改变任何标签；开发档案缺少同求解器的20 s轨迹。

五种主量测（干净、三档白噪声和30 dB等功率AR(1)）等权混合，各策略分别用同一未越限变体校准全局告警阈值；突变不参加校准。10\%目标的门控滚动与二次滚动是预设主要比较，及时命中率差应至少为2个百分点且95\%区间下限大于零，混合和突变虚警增量的区间上限分别不得超过2和5个百分点。5\%为次要工作点；按同一扰动前质量标记分别校准两策略为次要诊断，见补充表\ref{sup:tab:transfer-cutoffs}。区间按物理事件配对重采样，保留各量测变体。''')
    s=replace_par(s,'主要对照使用600个告警阈值校准场景',rf'''主要对照使用600个校准场景和1600个独立测试场景。291个越限中，98个在0.50 s及以前越限，固定时刻策略的及时命中理论上限为其余193个；实际命中189个，占可及时命中事件的97.93\%。同为5\%校准目标时，滚动在早越限组命中98/98，在晚越限组命中174/193。两者共同命中174个，仅滚动命中98个，仅固定命中15个，均未命中4个。83个净增来自早组增加98个、晚组减少15个，主要体现更早的决策机会。实际虚警为84/1309与74/1309。共同命中事件的中位提前量分别为460和210 ms；全部集合与虚警交集见补充表\ref{{sup:tab:original-sets}}。固定5\%实际虚警的事后曲线诊断仍显示滚动命中率较高，差{num(diag('original_clean',5).Delta_pp)}个百分点（95\%区间{bounds(diag('original_clean',5).Low_pp,diag('original_clean',5).High_pp)}），见补充表\ref{{sup:tab:matched-far}}。''')
    s=once(s,'{quality-assets/figures/quality-selection-performance.pdf}','{audit-figures/fixed-selection.pdf}')
    s=once(s,'观测质量、选择占比及单场景误差。虚线为两档冻结门槛。','固定0.50 s门控确认的逐条件表示选择，每柱分母为该条件下独立单事件量测变体。白40、白30、白20表示模拟白噪声信噪比，相关噪声为等功率AR(1)。')
    s=once(s,'Observable quality, representation selection, and single-event errors','Representation selection by observation condition at the 0.50 s cutoff')
    s=once(s,'{quality-assets/figures/quality-strategy-errors.pdf}','{audit-figures/fixed-mae.pdf}')
    s=once(s,'同一确认集上五种固定策略及门控的误差。上行为独立单场景，下行为配对差值。','固定截止门控确认的主要幅值指标。左图为128个独立单事件，右图主幅值集合为220对；含噪各10个复本。全指标及其他基线见补充材料。')
    # 在正文引用原详细图的补充编号，避免图注引用自身。
    detail=r'图\ref{sup:fig:fixed-q}与图\ref{sup:fig:fixed-errors}给出质量代理和完整基线。'
    # 把补充图指引放进5.2节，沿用原段落中的正式指标。
    a=next(x for x in s.splitlines() if '全部20项预设门槛通过' in x and 'fig:strategy' in x)
    s=once(s,a,a.replace('汇总全部固定策略和门控误差','对照各条件下的主要MAE')+' 补充'+detail)

    start=s.index(r'\subsection{ECGR质量门控接入滚动告警的独立补充试验}')
    end=s.index(r'\section{IEEE 39节点数值压力检验}',start)
    lines=[]
    for scope in ('mixed','jump'):
        for pol in ('quadratic','gate','persistence','endpoint','ecgr','gate_final_only'):
            k=al(scope,pol)
            lines.append(row([scopes[scope],names[pol],val(k.PooledCut_Hz,5),f'{k.Hits}/{k.RiskVariants}',
                              f'{k.FalseAlarms}/{k.NonriskVariants}',num(k.HitRatePct),num(k.FARPct),val(k.LeadMedian_ms)]))
    tab=table(r'新增滚动接入试验的绝对计数，10\%告警校准目标。混合项含2400个物理事件、12000个变体；突变单列。持续性等为事后补列的非主对照。','tab:transfer-abs','llrrrrrr',
              ['量测','策略','阈值/Hz','命中/越限','虚警/未越限',r'命中/\%',r'虚警/\%','提前/ms'],lines)
    body=rf'''\subsection{{ECGR质量门控接入滚动告警的独立试验}}
表\ref{{tab:transfer-abs}}采用同批场景、同一10\%校准目标，各策略分别校准。五条件共享409个越限、1991个未越限物理事件，分别形成2045与9955个量测组合。门控及时命中率从{rate(q.HitRatePct)}升至{rate(g.HitRatePct)}，差{num(e.HitDelta_pp)}个百分点（95\%区间{pair('HitLow_pp','HitHigh_pp',e)}）。实际虚警由{q.FalseAlarms}/9955升至{g.FalseAlarms}/9955，差{num(e.FARDelta_pp)}个百分点，区间{pair('FARLow_pp','FARHigh_pp',e)}。上限2.58超过保护线2个百分点，主验收未通过。突变时虚警下降{num(-j.FARDelta_pp)}个百分点，命中差的区间跨零。提前量仅在各策略自身及时命中集合上取中位数。

同批持续性为新增事后对照。混合条件下持续性命中率{rate(p.HitRatePct)}、虚警率{rate(p.FARPct)}，点估计均优于门控；门控减持续性的命中差为{num(b.HitDelta_pp)}个百分点，区间{pair('HitLow_pp','HitHigh_pp',b)}。这组比较不改变预设验收。5\%次要工作点相对二次滚动增加{num(a5.HitDelta_pp)}个百分点命中并减少{num(-a5.FARDelta_pp)}个百分点虚警；它不能替代主要结果。分级阈值诊断相对分级二次滚动的命中差为{num(st.HitDelta_pp)}个百分点，实际虚警差区间{pair('FARLow_pp','FARHigh_pp',st)}。各量测条件的实际工作点见补充表\ref{{sup:tab:transfer-full}}，选择比例与工作点见补充图\ref{{sup:fig:transfer-select}}和图\ref{{sup:fig:transfer-op}}。

干净条件下两条混合校准阈值分别为{q.PooledCut_Hz:.5f}与{g.PooledCut_Hz:.5f} Hz。阈值交换矩阵的对称分解中，{num(C.Total_pp)}个百分点的命中差有{num(C.CutoffContribution_pp)}个百分点对应阈值切换，{num(C.ScoreContribution_pp)}个百分点对应评分切换。它描述该工作点下的代数组成。相同5\%实际虚警的事后插值中，干净条件命中差缩为{num(diag('transfer_clean',5).Delta_pp)}个百分点，而五条件混合为{num(diag('transfer_mixed',5).Delta_pp)}个百分点。相同实际虚警的诊断以确认数据重建曲线，不代表可部署的阈值选择，见补充表\ref{{sup:tab:matched-far}}。
'''
    s=s[:start]+body+'\n'+tab+'\n\n'+s[end:]
    s=replace_par(s,'固定截止门控与原滚动阈值分级分别验证。',r'''原滚动比较的净增命中主要由早越限事件获得提前决策机会。新增试验将ECGR质量门控接入四个决策窗，在部分工作点相对二次表示提高及时命中。10\%主要比较的虚警保护未通过，同批持续性点估计也优于门控。噪声突变、阈值与评分交互、提前量分母及事件结构应共同解释。新增证据限于聚合仿真，IEEE 39节点仍为原冻结策略的数值压力检验。''')
    s=replace_par(s,'新增的ECGR门控滚动试验中',r'''新增滚动迁移试验确认了门控接入后的及时命中收益及其代价。10\%主要比较未通过虚警保护，同批持续性仍是重要对照。固定截止门控、固定ECGR、滚动迁移和单侧下界的验收应按各自协议解释。''')
    s=add(s,r'\end{thebibliography}',r'\bibitem{aitken1936} AITKEN A C. IV.—On least squares and linear combination of observations[J]. Proceedings of the Royal Society of Edinburgh, 1936, 55: 42--48. DOI: 10.1017/S0370164600014346.')
    save('frequency-project.tex',s)

def edit_supp():
    # 封版：先结束正文段，再放入S11和S12两个浮动表。
    s=move_sentence(txt(V/'frequency-project-supplement.tex'))
    s=once(s,r'\renewcommand{\thetable}{S\arabic{table}}',r'\renewcommand{\thetable}{S\arabic{table}}'+'\n'+r'\renewcommand{\thefigure}{S\arabic{figure}}')
    s=s[:s.index(r'\section{ECGR接入滚动告警的补充复算}')]
    # 历史图的中文说明转为计数器驱动的图题；移除文本型伪编号。
    s=re.sub(r'\\captionofdummy\{(?:附图\d+\\quad )?([^{}]+)\}',r'\\captionof{figure}{\1}',s)
    s=once(s,r'\includegraphics[width=.82\linewidth]{rolling-figures/r2-paired-noise.pdf}\\'+'\n'+r'噪声实现差值图\quad 每个噪声实现中二次拟合相对持续性的及时命中差',
           r'\includegraphics[width=.82\linewidth]{rolling-figures/r2-paired-noise.pdf}'+'\n'+r'\captionof{figure}{前期多机固定场景中的40个噪声实现，二次拟合减持续性的及时命中计数。每个实现有126个越限组合。}')
    historic_figs={
        'assets/noise-comparison.pdf':'固定截止原噪声对照的绝对误差统计。各噪声结构采用相同物理事件。',
        'assets/endpoint-scan.pdf':'等端点参数扫描的后缀极值差；每条曲线对应一个参考缺额。',
        'assets/structure-states.pdf':'单级及两级调频结构的数值轨迹与调频响应对照。',
        'assets/matched-and-sensitivity.pdf':'等端点匹配扫描及局部灵敏度指标。参数带与噪声条件依原协议。',
        'assets/coverage-width.pdf':'固定截止双侧预测区间的覆盖与区间宽度。各组分母见相邻表。'}
    for path,cap in historic_figs.items():
        pattern=r'(\\includegraphics\[[^\]]+\]\{'+re.escape(path)+r'\})'
        s,n=re.subn(pattern,lambda m:m[0]+'\n'+r'\captionof{figure}{'+cap+'}',s,count=1)
        assert n==1,path
    # 对旧版只有粗体标题的表改用caption。保存已有正式编号和标签。
    s=re.sub(r'\\begin\{center\}\\textbf\{(?:分布式阶跃对照|追加场景噪声校准对照|早期留出对照)[^{}]*\}(?:\\\\)?\s*(?:\\small [^\n]+\n)?\\end\{center\}\s*','',s)
    s=re.sub(r'\\begin\{center\}\s*\\textbf\{噪声实现对照[^{}]*\}\\\\\s*\\small [^\n]+\n\\end\{center\}\s*','',s)
    nam={
      1:'本机计算耗时。耗时用于复现记录。',
      2:'固定截止双侧区间的覆盖、宽度与偏向。',
      10:'早期多机算例的直接迁移对照，按可评分场景计数。',
      11:'IEEE 14及39节点分布式阶跃的预警与本地校准。',
      12:'IEEE 39追加场景的预警与匹配噪声校准。',
      13:r'前期IEEE 39固定场景的40个噪声实现，10\%目标虚警下的平均及时命中。',
      14:r'早期未见物理场景的事件级滚动预警，10\%校准目标。',
      15:'数值积分诊断中的步长、最后可用时刻与越限状态。'}
    starts=list(re.finditer(r'\\begin\{tabular\}',s))
    assert len(starts)==16
    for i,m in reversed(list(enumerate(starts,1))):
        if i in nam:
            caption=r'\captionof{table}{'+nam[i]+'}'
            if i in (1,2):
                end=s.index(r'\end{tabular}',m.start())+len(r'\end{tabular}')
                s=s[:m.start()]+r'\begin{minipage}{\linewidth}\centering'+'\n'+caption+'\n'+s[m.start():end]+'\n'+r'\end{minipage}'+s[end:]
            else:
                s=s[:m.start()]+caption+'\n'+s[m.start():]

    # 三张独立数据长表过去没有标题，本次在各长表中登记原生标题。
    for name,cap in [('ecgr-table','固定截止ECGR确认中的配对差值指标。'),
                     ('quality-table','固定截止质量门控的逐条件确认指标。'),
                     ('mis-table','固定截止门控的误选与误选损失诊断。')]:
        f=D/'quality-assets'/f'{name}.tex'
        t=txt(V/'quality-assets'/f'{name}.tex')
        t=re.sub(r'(\\begin\{longtable\}\{[^{}]+\})',
                 lambda m:m[0]+'\n'+r'\caption{'+cap+r'}\\',t,count=1)
        # 续页只重印列名，避免将首个标题重复登记为同号新表。
        head=re.search(r'(\\toprule.*?)(?=\\endhead)',t,re.S)
        assert head, name
        t=t.replace(r'\endhead',r'\endfirsthead'+'\n'+head[1]+r'\endhead',1)
        f.write_text(t,encoding='utf-8')
    result=[s,r'\clearpage\section{固定截止附加图件}',
            fig('quality-assets/figures/quality-selection-performance.pdf','固定截止独立确认。左为128个单场景在各条件的表示比例，右为质量代理与绝对误差；含噪条件每物理事件10个复本。','fig:fixed-q'),
            fig('quality-assets/figures/quality-strategy-errors.pdf','固定截止独立确认。上行为128个单场景，下行为220个主幅值配对，含噪条件每物理事件10个复本。误差单位为mHz。','fig:fixed-errors'),
            r'\clearpage\section{原滚动与固定时刻的逐事件分解}']
    labels={'all_risk':'全体越限','early':r'首次越限 $\leq 0.50$ s','late':r'首次越限 $>0.50$ s','both_hits':'共同命中','rolling_only':'仅滚动命中','fixed_only':'仅固定命中',
            'neither_hit':'均未命中','all_nonrisk':'全部未越限','both_false':'共同虚警','rolling_only_false':'仅滚动虚警','fixed_only_false':'仅固定虚警','neither_false':'均未虚警'}
    result.append(table('原滚动与固定策略的集合分解。提前量只对各行中及时命中者统计，未越限组的分母为1309。','tab:original-sets','lrrrrrrr',
                        ['集合','物理事件','滚动命中','固定命中','滚动提前/ms','固定提前/ms','滚动虚警','固定虚警'],
                        [row([labels[k],count_text(x.Events),count_text(x.RollingHits),count_text(x.FixedHits),
                              val(x.RollingLeadMedian_ms),val(x.FixedLeadMedian_ms),
                              count_text(x.RollingFalse),count_text(x.FixedFalse)]) for k,x in G.iterrows()]))
    result.append(r'''固定0.50 s策略在193个晚越限事件中命中189个。早越限组没有固定策略可计算的及时提前量。虚警计算限于未越限事件，风险组逐集合不另造虚警分母。''')
    result.append(r'\clearpage\section{滚动ECGR接入试验的完整工作点}')
    result.append(r'''绝对值来自2400个物理事件。五种主量测等权，每个事件在各主条件各出现一次；混合分母为2045个越限和9955个未越限组合，突变单列。各单条件共有409个越限、1991个未越限。提前量只对本策略命中集合取中位数。标记“主”是预设10\%两策略，“次”是锁定5\%工作点，“分”是同规则分别分级校准的次要诊断，“事”是事后补表。持续性不是预设主要对照。''')
    full=[]
    for scope in scopes:
        for t in (.1,.05):
            for pol in names:
                x=al(scope,pol,t)
                role='主' if pol in ('gate','quadratic') and t==.1 else ('次' if pol in ('gate','quadratic') else ('分' if 'stratified' in pol else '事'))
                cut=val(x.PooledCut_Hz,4) if pd.isna(x.HighQualityCut_Hz) else f'{x.HighQualityCut_Hz:.4f}/{x.LowQualityCut_Hz:.4f}'
                full.append(row([scopes[scope],int(t*100),names[pol],role,cut,f'{x.Hits}/{x.RiskVariants}',
                                 f'{x.FalseAlarms}/{x.NonriskVariants}',num(x.HitRatePct),num(x.FARPct),val(x.LeadMedian_ms)]))
    result.append(table(r'滚动接入各策略绝对工作点，比例为\%。分级阈值写作高质量/低质量。','tab:transfer-full','lrlclrrrrr',
                       ['量测','目标','策略','属性','阈值/Hz','命中/越限','虚警/未越限','命中率','虚警率','提前/ms'],full,True))
    thr=[]
    for t in (.1,.05):
        for pol in names:
            x=al('mixed',pol,t)
            thr.append(row([int(t*100),names[pol],val(x.PooledCut_Hz,9),val(x.HighQualityCut_Hz,9),val(x.LowQualityCut_Hz,9)]))
    result.append(table(r'冻结告警阈值（Hz）。分级策略读同一可观测质量标记，并各自使用高低质量阈值；其全局阈值只作回退。','tab:transfer-cutoffs','rlrrr',
                        [r'目标/\%','策略','全局阈值','高质量阈值','低质量阈值'],thr,True))
    result.append(r'\clearpage')
    out=[]
    for scope in scopes:
        x=ep(scope)
        out.append(row([scopes[scope],num(x.HitDelta_pp)+' '+pair('HitLow_pp','HitHigh_pp',x),num(x.FARDelta_pp)+' '+pair('FARLow_pp','FARHigh_pp',x)]))
    result.append(table(r'10\%校准目标的预设比较。正差为门控指标更高，虚警正差表示代价。事件簇为2400个物理事件，区间为95\%。','tab:transfer-effects','lrr',
                        ['条件','命中差/百分点','虚警差/百分点'],out))
    z=ep('mixed',q='persistence')
    result.append(rf'''两种比例的区间按4000次物理事件配对重采样。混合虚警差区间上限2.58个百分点超过预设2个百分点，主验收未通过（三项通过、一项失败）。10\%目标下，门控相对同批持续性的命中差为{num(z.HitDelta_pp)}、虚警差为{num(z.FARDelta_pp)}个百分点，配对区间分别为{pair('HitLow_pp','HitHigh_pp',z)}、{pair('FARLow_pp','FARHigh_pp',z)}。其余策略与两档工作点的配对区间见随附联合结果表。''')
    result.append(fig('rolling-figures/paired-event-effects.pdf','10\\%校准目标下预设主要比较的量测分层效应。门控减二次滚动，横坐标为百分点；线段为以2400个物理事件为簇的95\\%区间。','fig:transfer-effect'))
    result.append(r'\clearpage')
    result.append(fig('audit-figures/rolling-discrete-selection.pdf','2400个物理事件在四个决策窗的离散选择比例，每柱分母为2400。分层来自模拟量测标签，选择只用当前窗与共用扰动前量测。','fig:transfer-select','.87'))
    result.append(fig('audit-figures/rolling-operating-points.pdf','10\\%校准目标下五种主条件等权的实测工作点。命中和虚警的分母分别为2045和9955个组合；持续性等为非主对照，绝对结果见表\\ref{tab:transfer-full}。','fig:transfer-op','.77'))
    result.append(r'\clearpage\section{告警工作点的事后诊断}')
    result.append(r'''绝对阈值互换在原10\%全局阈值上做02型对照。用两种评分分别套用两个阈值，分别得到四个命中率；将阈值变化在两种评分上取平均，再将评分变化在两个阈值上取平均，两项之和等于原差。这个分解依赖使用同一绝对Hz刻度及原测试集，属于描述性诊断。'''.replace('02型','二乘二'))
    result.append(table('干净量测下同一评分使用两个固定阈值的诊断。分母为409个越限和1991个未越限。','tab:threshold-swap','llrrrrr',
        ['评分','阈值来源','阈值/Hz','命中','虚警',r'命中率/\%',r'虚警率/\%'],
        [row([names[x.Score],names[x.CutoffOrigin],val(x.Cutoff_Hz,6),x.Hits,x.FalseAlarms,num(x.HitPct),num(x.FARPct)]) for x in C4.itertuples()]))
    result.append(r'''同实际虚警诊断预先只用5\%、10\%两个坐标。未越限事件用全部可用窗的最小值，越限事件用首次越限前各窗最小值；无可及时出分的越限事件仍留在分母。按预测值升序纳入同分组；虚警率平台取最早阈值，从不告警原点开始。在相邻可达虚警率之间线性插值，禁止外推，无法形成括点的复本标为不可用。区间由4000次配对物理事件重采样获得，每次重新构造插值括点，所有复本均可插值。诊断使用测试记录，不能用来重新校准主要阈值。''')
    label={'transfer_mixed':'新增混合','transfer_clean':'新增干净','original_clean':'原滚动干净'}
    result.append(table('相同实际虚警率下的成对事后诊断。前两组为门控减二次滚动，原滚动组为滚动减固定时刻。','tab:matched-far','lrrrrr',
        ['数据',r'实际虚警/\%',r'策略命中/\%',r'对照命中/\%','命中差/百分点','95\\%区间'],
        [row([label[x.Dataset],val(x.ActualFAR_pct),num(x.PolicyHit_pct),num(x.ComparatorHit_pct),num(x.Delta_pp),bounds(x.Low_pp,x.High_pp)]) for x in H.itertuples()]))
    result.append(r'\end{document}')
    save('frequency-project-supplement.tex','\n\n'.join(result))

if __name__=='__main__':
    edit_main()
    edit_supp()
