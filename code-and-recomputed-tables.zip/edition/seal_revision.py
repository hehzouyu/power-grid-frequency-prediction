"""封版微修：从已核验旧备份生成新版；只移动一句正文和格式化S20五列。
编译失败、定位不唯一或旧表与冻结计数不同会抛出异常，保留工作日志。
"""
from argparse import ArgumentParser
import csv
from decimal import Decimal
from difflib import unified_diff
from hashlib import sha256
import json
from pathlib import Path
import re
from shutil import copy2
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
SUP = "frequency-project-supplement"
MAIN = "frequency-project"
ARCHIVE = "完整LaTeX源码及图片.zip"
DATA = "复算表/原滚动命中集合.csv"
SENTENCE = "两种时序误差只改变输入的采样位置，事件真值依真实扰动时间轴定义。"
PREFIX, SUFFIX = SENTENCE.split("动时间轴定义。")[0], "动时间轴定义。"
COUNT_COLS = {1:"Events",2:"RollingHits",3:"FixedHits",6:"RollingFalse",7:"FixedFalse"}
OLD_COUNT = re.compile(r"(\d+)\.0")

def require(condition, message):
    if not condition:
        raise ValueError(message)

def load(path):
    return path.read_text(encoding="utf-8")

def put(path,text):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(text.encode("utf-8"))

def preserve_newlines(old, target, revised):
    # 仅在内存中转换换行以匹配锚点，写出仍沿用旧文件的换行格式。
    data=old.read_bytes()
    sep=b"\r\n" if b"\r\n" in data else b"\n"
    require(b"\r" not in data.replace(sep,b"") and b"\n" not in data.replace(sep,b""),"旧源码具有混合换行")
    target.write_bytes(revised.encode("utf-8").replace(b"\n",sep))

def one(text, old, new):
    require(text.count(old)==1, f"无法唯一定位：{old!r}")
    return text.replace(old,new,1)

def move_sentence(source):
    """在表S11开始前结束普通正文段落，将末尾原句整体移至该位置。"""
    require(source.count(SENTENCE)==1, "目标原句必须恰好出现一次")
    anchor = re.compile(r"(?m)^\\begin\{table\}\[!htbp\]\\centering\\small\n"
                        r"\\caption\{[^\n]+\}\\label\{tab:full-roll\}$")
    matches=list(anchor.finditer(source))
    require(len(matches)==1,"S11浮动体定位失败")
    first = matches[0][0]
    last = SENTENCE+"\n"+r"\begin{center}"+"\n"+r"\includegraphics[width=.46\linewidth]{rolling-figures/lead.pdf}"
    require(source.find(SENTENCE)>matches[0].start(),"移动前目标原句应位于S11之后")
    result=one(source,last,last[len(SENTENCE)+1:])
    result=one(result,first,"\n"+SENTENCE+"\n\n"+first)
    require(result.count(SENTENCE)==1 and result.index(SENTENCE)<result.index(first),"原句位置校验失败")
    return result

def count_text(x):
    """整数格式化前明确验证有限、非负且无小数，避免截断异常输入。"""
    n=Decimal(str(x))
    require(n.is_finite() and n>=0 and n==n.to_integral_value(),f"非整数计数：{x}")
    return str(int(n))

def format_s20(tex, frozen_path):
    """只处理带原标签的S20数据区，将60个整数与保存的CSV逐格核对。"""
    label=r"\label{tab:original-sets}"
    require(tex.count(label)==1,"S20标签必须唯一")
    start=tex.index("\\midrule\n",tex.index(label))+len("\\midrule\n")
    end=tex.index("\\bottomrule",start)
    fragment=tex[start:end]
    rows=fragment.splitlines()
    with frozen_path.open(encoding="utf-8-sig",newline="") as stream:
        frozen=list(csv.DictReader(stream))
    require(len(rows)==len(frozen)==12,"S20应有且只有12个数据行")
    newrows=[]
    for row, event in zip(rows,frozen,strict=True):
        require(row.endswith(r" \\"),"S20行尾格式异常")
        cells=row[:-3].split(" & ")
        require(len(cells)==8,"S20列数异常")
        for col, key in COUNT_COLS.items():
            original = OLD_COUNT.fullmatch(cells[col])
            correct = count_text(event[key])
            require(original is not None and original[1]==correct, f"S20计数与原表或冻结CSV不符：{row} / {key}")
            cells[col]=correct
        for col,key in [(4,"RollingLeadMedian_ms"),(5,"FixedLeadMedian_ms")]:
            expected="--" if event[key]=="NaN" else count_text(event[key])
            require(cells[col]==expected,f"S20提前量或缺测记号不符：{row}")
        newrows.append(" & ".join(cells)+r" \\")
    updated="\n".join(newrows)+"\n"
    require(fragment!=updated and tex.count(fragment)==1,"S20替换区必须唯一且发生预期变化")
    return tex[:start]+updated+tex[end:],rows,newrows

def patch_generator(original):
    """旧生成器仍以v2及既有复算CSV为输入。保留其余生成规则。"""
    original=one(original,"import pandas as pd\n","import pandas as pd\nfrom seal_revision import count_text, move_sentence\n")
    original=one(original,
        "    s=txt(V/'frequency-project-supplement.tex')\n",
        "    # 封版：先结束正文段，再放入S11和S12两个浮动表。\n"
        "    s=move_sentence(txt(V/'frequency-project-supplement.tex'))\n")
    original=one(original,
        "[labels[k],x.Events,x.RollingHits,x.FixedHits,val(x.RollingLeadMedian_ms),val(x.FixedLeadMedian_ms),\n"
        "                              x.RollingFalse,x.FixedFalse]",
        "[labels[k],count_text(x.Events),count_text(x.RollingHits),count_text(x.FixedHits),\n"
        "                              val(x.RollingLeadMedian_ms),val(x.FixedLeadMedian_ms),\n"
        "                              count_text(x.RollingFalse),count_text(x.FixedFalse)]")
    return original

def call(args, root, log=None):
    done = subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if log:
        log.write_bytes(done.stdout)
    if done.returncode:
        raise RuntimeError(f"{args[0]} 遇到错误，详见 {log or root}：{done.stdout[-1300:]!r}")
    return done.stdout

def latex(root, records, suffix):
    """先补充后主稿；使用latexmk自动重复XeLaTeX直到辅助文件稳定。"""
    for stem in (SUP,MAIN):
        args=["latexmk","-xelatex","-interaction=nonstopmode","-halt-on-error",stem+".tex"]
        call(args,root,records/f"{suffix}-{stem}-编译.txt")
        aux=root/(stem+".aux")
        before=aux.read_bytes()
        call(args,root,records/f"{suffix}-{stem}-稳定性.txt")
        require(before==aux.read_bytes(),f"{stem} 交叉引用尚未稳定")
        log=load(root/(stem+".log"))
        require(not re.search(r"(?im)^(?:! |.*(?:Missing character|LaTeX Error|undefined references|multiply defined|Overfull|Reference .*undefined))",log),
                f"{stem} 日志存在未定义引用、缺字或越界")
        copy2(root/(stem+".log"),records/f"{suffix}-{stem}.log")

def pdf_artifacts(root, output):
    output.mkdir(parents=True,exist_ok=True)
    for stem in (SUP,MAIN):
        call(["pdftotext","-layout",str(root/(stem+".pdf")),str(output/(stem+".txt"))],root)
        call(["pdftoppm","-png","-r","85",str(root/(stem+".pdf")),str(output/stem)],root)

def normalized(s):
    return " ".join(s.split())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def images(dir,stem):
    return sorted(dir.glob(stem+"-[0-9][0-9].png"))

def rawpages(path):
    return load(path).rstrip("\f").split("\f")

def number_lists(aux, stem):
    s=load(aux)
    return {kind:re.findall(r"\\contentsline \{"+kind+r"\}\{\\numberline \{("+("S" if stem==SUP else "")+r"\d+)\}",s)
            for kind in ("figure","table")}

def diff_report(records,title,before,after):
    difference="".join(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
                                    fromfile=f"修改前/{title}",tofile=f"修改后/{title}"))
    put(records/(title+".diff"),difference)

def validate(old, after, oldrender, newrender, cleanrender, records, oldrows, newrows):
    """单页验证。主稿提取文本与像素全同；补录仅允许两处目标差异。"""
    for stem in (SUP,MAIN):
        require(number_lists(old/(stem+".aux"),stem)==number_lists(after/(stem+".aux"),stem),f"{stem}图表编号变化")
        new=load(newrender/(stem+".txt"))
        require(new==load(cleanrender/(stem+".txt")),f"源码包重编译：{stem}文本不一致")
    require((old/(MAIN+".tex")).read_bytes()==(after/(MAIN+".tex")).read_bytes(),"主稿源码不同")
    require(load(oldrender/(MAIN+".txt"))==load(newrender/(MAIN+".txt")),"主稿PDF提取文本不同")
    oldpages=rawpages(oldrender/(SUP+".txt"))
    newpages=rawpages(newrender/(SUP+".txt"))
    require(len(oldpages)==len(newpages)==27,"补充材料分页改变，请保留日志并检查实际分页")
    require(len(rawpages(newrender/(MAIN+".txt")))==23,"主稿页数不是23")
    require(normalized("".join(newpages)).count(SENTENCE)==1,"渲染提取文本中完整句应只出现一次")
    require(not re.search(r"(?m)^\s*"+re.escape(SUFFIX)+r"\s*$",newpages[12]),"仍有历史孤立残句")
    require(newpages[12].index(SENTENCE)<newpages[12].index("表 S11"),"目标句未置于表S11之前")
    for index,(before,revised) in enumerate(zip(oldpages,newpages,strict=True),1):
        if index==13:
            before=one(before,PREFIX,"")
            before=one(before,SUFFIX,"")
            revised=one(revised,SENTENCE,"")
        if index==20:
            bl,rl=before.splitlines(),revised.splitlines()
            # 根据同一行的表键及理论列数定位。保持前两列可能被PDF插入的空白不敏感。
            def values(lines, texrows):
                found=[]
                for row in texrows:
                    cols=row[:-3].split(" & ")
                    key=cols[0].split(" $")[0]
                    candidates=[(i,line) for i,line in enumerate(lines) if line.strip().startswith(key)]
                    match=[(i,line) for i,line in candidates if line.split()[-7:]==[v.replace("--","–") for v in cols[1:]]]
                    if not match:
                        match=[(i,line) for i,line in candidates if [v if v not in {"-","–","—","−"} else "--" for v in line.split()[-7:]]==cols[1:]]
                    require(len(match)==1,f"PDF中目标行定位失败：{row}；候选 {candidates}")
                    found.append(match[0][0])
                require(len(set(found))==12,"PDF S20行未唯一匹配")
                return "\n".join(line for i,line in enumerate(lines) if i not in found)
            before,revised=values(bl,oldrows),values(rl,newrows)
        require(normalized(before)==normalized(revised),f"补充材料第{index}页出现非目标文本变化")
    rows=[]
    for stem,expected in ((SUP,27),(MAIN,23)):
        page_sets=[images(path,stem) for path in (oldrender,newrender,cleanrender)]
        require(all(len(imgs)==expected for imgs in page_sets),"渲染页数不符")
        for index, triple in enumerate(zip(*page_sets,strict=True),1):
            first,second,third=map(digest,triple)
            require(second==third,f"{stem}第{index}页源码包复编译像素不同")
            require((first==second)==(stem==MAIN or index not in (13,20)),f"{stem}第{index}页旧新像素差异超出目标")
            rows.append([stem,index,*[first,second,third],"目标页变化" if first!=second else "相同"])
    with (records/"逐页像素校验.csv").open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.writer(f); w.writerow(["稿件","页码","旧版PNG SHA-256","新版PNG SHA-256","源码包重编PNG SHA-256","旧新对照"]); w.writerows(rows)

def build(old, destination):
    records=destination/"核验"
    records.mkdir(exist_ok=True)
    sha=json.loads(load(old.parent/"修改前-SHA256.json"))
    require(all(digest(old/name)==h for name,h in sha.items()),"备份SHA-256校验失败")
    tex_before=load(old/(SUP+".tex"))
    updated, oldrows, newrows = format_s20(move_sentence(tex_before),old/DATA)
    old_generator=load(old/"revise.py")
    new_generator=patch_generator(old_generator)
    py=destination/"revise.py"
    preserve_newlines(old/"revise.py",py,new_generator)
    copy2(old/DATA,destination/"S20冻结计数只读副本.csv")
    require(digest(old/DATA)==digest(destination/"S20冻结计数只读副本.csv"),"冻结计数副本哈希不一致")
    diff_report(records,SUP+".tex",tex_before,updated)
    diff_report(records,"revise.py",old_generator,new_generator)
    with ZipFile(old/ARCHIVE) as z:
        require(z.testzip() is None,"旧源码包校验失败")
        z.extractall(destination)
        names=z.namelist()
    preserve_newlines(old/(SUP+".tex"),destination/(SUP+".tex"),updated)
    with ZipFile(destination/ARCHIVE,"w",ZIP_DEFLATED,compresslevel=6) as z:
        for name in names:
            z.write(destination/name,name)
    oldrender=records/"旧版"
    newrender=records/"新版"
    latex(destination,records,"交付版")
    pdf_artifacts(old,oldrender)
    pdf_artifacts(destination,newrender)
    with TemporaryDirectory(prefix="seal-paper-") as temp:
        clean=Path(temp)
        with ZipFile(destination/ARCHIVE) as z:
            require(z.testzip() is None and z.namelist()==names,"新版ZIP文件集异常")
            for name in names:
                prior=(old/name).read_bytes()
                require((z.read(name)!=prior)==(name==SUP+".tex"),f"ZIP出现未授权成员差异：{name}")
            z.extractall(clean)
        latex(clean,records,"源码包")
        cleanrender=clean/"render"
        pdf_artifacts(clean,cleanrender)
        validate(old,destination,oldrender,newrender,cleanrender,records,oldrows,newrows)
    diff_report(records,SUP+".PDF提取文本",load(oldrender/(SUP+".txt")),load(newrender/(SUP+".txt")))
    # 主稿实验结论与原PDF证据完全相同，交付直接留用原版PDF的全部字节和书签。
    copy2(old/(MAIN+".pdf"),destination/(MAIN+".pdf"))
    require(digest(old/(MAIN+".pdf"))==digest(destination/(MAIN+".pdf")),"主稿PDF复制错误")
    print("PASS: 27页补充材料仅改第13/20页，23页主稿像素和文本相同；源码包独立构建一致。")

if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("backup",type=Path,help="修改前-v3备份目录")
    args=parser.parse_args()
    build(args.backup.resolve(),HERE)

