"""Add the preregistered rolling-transfer evaluation to a new combined manuscript."""
from pathlib import Path
from shutil import copytree, copy2
import csv
import re
import json
from zipfile import ZipFile,ZIP_DEFLATED

D=Path(__file__).resolve().parent
BASE=D.parent/"2026-11-21-项目总稿-v1"
NEW=D.parent/"2026-11-21-项目总稿-v2"
PREFIX="frequency-project"
P=json.loads((D/"protocol.json").read_text(encoding="utf-8-sig"))

def data(name,key):
    with (D/name).open(encoding="utf-8-sig",newline="") as f:
        return {tuple(row[k] for k in key):row for row in csv.DictReader(f)}

def pct(x): return f"{float(x)*100:.2f}"
def number(x): return f"{float(x):.2f}".replace("-","−")
def ci(row,a,b): return f"[{number(row[a])}, {number(row[b])}]"

def once(s,before,after):
    assert s.count(before)==1,before
    return s.replace(before,after,1)

def replace_paragraph(s,prefix,body):
    paragraph=next(line for line in s.splitlines() if line.startswith(prefix))
    return once(s,paragraph,body)

def insert_before(s,anchor,extra):
    return once(s,anchor,extra+"\n\n"+anchor)

def build():
    NEW.mkdir(exist_ok=False)
    for name in ("assets","revision-assets","quality-assets","rolling-figures","evidence"):
        copytree(BASE/name,NEW/name)
    for file in ("文献核验表.csv","数字追溯索引.csv"):
        copy2(BASE/file,NEW/file)
    attach=NEW/"evidence/rolling-ecgr"
    attach.mkdir()
    for path in D.iterdir():
        if path.is_file() and path.suffix in {".csv",".gz",".json",".py",".joblib",".log",".md"}:
            copy2(path,attach/path.name)
        if path.is_file() and path.suffix==".pdf":
            copy2(path,NEW/"rolling-figures"/path.name)
    main=(BASE/f"{PREFIX}.tex").read_text(encoding="utf-8")
    supp=(BASE/f"{PREFIX}-supplement.tex").read_text(encoding="utf-8")
    metrics=data("event-metrics.csv",("Scope","TargetFAR","Policy"))
    effects=data("paired-effects.csv",("Scope","TargetFAR","Policy","Comparator"))
    targets=data("acceptance.csv",("Criterion",))
    q,g=[metrics["mixed","0.1",k] for k in ("quadratic","gate")]
    jq,jg=[metrics["jump","0.1",k] for k in ("quadratic","gate")]
    e=effects["mixed","0.1","gate","quadratic"]
    e5=effects["mixed","0.05","gate","quadratic"]
    j=effects["jump","0.1","gate","quadratic"]
    st=effects["mixed","0.1","gate_stratified","quadratic_stratified"]
    assert all(row["Pass"]=="True" for key,row in targets.items() if key!=("mixed FAR increase upper CI",))
    assert targets[("mixed FAR increase upper CI",)]["Pass"]=="False"
    method=r'''
针对固定截止ECGR门控能否迁移至滚动任务，另以原开发网格拟合四个决策窗的点预测器。开发标签取历史记录至扰动后19 s，校准和测试标签取至扰动后20 s，均仅包含各窗末之后的样本。ECGR沿用原端点约束、协方差混合和收缩参数，按窗宽重建矩阵；两个质量门槛不重新选择。阈值由800个独立校准事件确定，另用2400个新事件确认。每个事件在干净、三档白噪声和30 dB等功率AR(1)条件下各评分一次，突变单列。相同校准目标下分别校准各策略。主要比较预设为10\%目标的门控滚动相对二次拟合滚动。验收要求及时命中率增益至少2个百分点且配对95\%区间下限大于零，混合与突变虚警增量区间上限分别不超过2和5个百分点。
'''.strip()
    main=insert_before(main,r'\section{固定截止最低频率预测结果}',method)
    result=rf'''
\subsection{{ECGR质量门控接入滚动告警的独立补充试验}}
五种主条件等权时，在10\%校准目标下，门控与固定二次表示分别及时命中{g['Hits']}/{g['RiskVariants']}和{q['Hits']}/{q['RiskVariants']}个事件--量测组合，及时命中率从{pct(q['HitRate'])}\%升至{pct(g['HitRate'])}\%，差{number(e['DeltaHit_pp'])}个百分点（物理事件聚类95\%区间{ci(e,'HitLow95_pp','HitHigh95_pp')}）。实际虚警率从{pct(q['FAR'])}\%升至{pct(g['FAR'])}\%，差{number(e['DeltaFAR_pp'])}个百分点，区间为{ci(e,'FARLow95_pp','FARHigh95_pp')}。上限超过预设2个百分点，主验收未通过。噪声突变下，实际虚警率从{pct(jq['FAR'])}\%降至{pct(jg['FAR'])}\%，及时命中率差区间跨零{ci(j,'HitLow95_pp','HitHigh95_pp')}个百分点。预设的5\%校准目标为次要分析，门控的及时命中率改善{number(e5['DeltaHit_pp'])}个百分点，实际虚警率下降{number(-float(e5['DeltaFAR_pp']))}个百分点。两档结果共同说明工作点依赖阈值校准，次要分析不能替代主验收。分量测条件与分级阈值结果见补充材料。
'''.strip()
    main=insert_before(main,r'\section{IEEE 39节点数值压力检验}',result)
    discussion=r'''固定截止门控与原滚动阈值分级分别验证。新增聚合确认说明，ECGR质量门控可以在多个决策窗接入滚动策略，提前期的表示选择会改变命中与虚警。10\%目标下，主验收的虚警上限未通过，尽管另一档校准目标显示两项指标同时改善。固定截止双侧区间覆盖、单侧安全判定与滚动首触发仍遵循各自分母。新增接入结果限于聚合仿真，IEEE 39节点压力试验仍评价其原冻结策略。'''
    main=replace_paragraph(main,'固定截止门控与滚动阈值分级分别验证。',discussion)
    conclusion=r'''新增的ECGR门控滚动试验中，门控提高了混合量测条件下的及时命中率，但10\%校准目标下实际虚警增量区间未满足预设上限。该结果界定了形状门控由精度任务迁移到事件决策时的适用边界。'''
    main=insert_before(main,r'\noindent\textbf{数据与代码可用性：}',conclusion)
    main=once(main,"噪声突变、IEEE 39节点压力检验和单侧下界失败共同限定所设数值条件下的适用范围。",
              "ECGR接入滚动后增加及时命中，主试验虚警保护未通过。IEEE 39节点压力检验和单侧下界试验进一步限定适用范围。")
    main=once(main,"Noise jumps, IEEE 39-bus stress tests and one-sided bound failures delimit the simulation evidence.",
              "In a separate rolling transfer test, ECGR gating increased timely hits but failed the primary false-alarm guard. The evidence is numerical.")
    detail=[r'\clearpage',r'\section{ECGR接入滚动告警的补充复算}',
        rf'''按物理事件聚类重采样{P['bootstrap_draws']}次，保持每个事件的量测变体及各策略成对进入或离开复本。混合条件涉及{g['EventCount']}个物理事件，{g['RiskVariants']}个越限组合及{g['NonriskVariants']}个未越限组合。正差表示门控指标更高，虚警增加代表代价。''',
        r'\begin{table}[!htbp]\centering\small',
        r'\caption{10\%校准目标下，门控减固定二次表示的成对滚动告警效应。单位为百分点。}',
        r'\begin{tabular}{lrr}\toprule 量测条件 & 及时命中差值 [95\%区间] & 虚警差值 [95\%区间]\\ \midrule']
    for k,label in (("mixed","五条件等权"),("clean","干净"),("white40","白噪声40 dB"),
                    ("white30","白噪声30 dB"),("white20","白噪声20 dB"),("ar30","AR(1) 30 dB"),("jump","噪声突变")):
        row=effects[k,"0.1","gate","quadratic"]
        detail.append(f'{label} & {number(row["DeltaHit_pp"])} {ci(row,"HitLow95_pp","HitHigh95_pp")} & {number(row["DeltaFAR_pp"])} {ci(row,"FARLow95_pp","FARHigh95_pp")}'+r' \\')
    detail+=[r'\bottomrule\end{tabular}\end{table}',
             rf'''在相同的扰动前质量分级阈值规则下，10\%校准目标的次要比较中，接入门控的及时命中率差为{number(st['DeltaHit_pp'])}个百分点，区间{ci(st,'HitLow95_pp','HitHigh95_pp')}；实际虚警率差为{number(st['DeltaFAR_pp'])}个百分点，区间{ci(st,'FARLow95_pp','FARHigh95_pp')}。该对照未用于改变主要比较或阈值。''',
             r'\begin{center}\includegraphics[width=.86\linewidth]{rolling-figures/paired-event-effects.pdf}\captionofdummy{预设主要比较在各量测条件下的结果。}\end{center}',
             r'\clearpage\begin{center}\includegraphics[width=.81\linewidth]{rolling-figures/selection-by-window.pdf}\captionofdummy{各决策窗的实际选择。真实噪声条件只用于分层展示。}\end{center}',
             r'\begin{center}\includegraphics[width=.69\linewidth]{rolling-figures/operating-points.pdf}\captionofdummy{不同表示策略的实际告警工作点。}\end{center}']
    supp=insert_before(supp,r'\end{document}',"\n\n".join(detail))
    for name,source in ((PREFIX+".tex",main),(PREFIX+"-supplement.tex",supp)):
        (NEW/name).write_text(source,encoding="utf-8")
    with (NEW/"数字追溯索引.csv").open("a",encoding="utf-8",newline="") as f:
        csv.writer(f).writerow(["ECGR滚动接入","主要和次要告警指标、逐窗选择及预设验收",
                 "本轮独立聚合重新生成","evidence/rolling-ecgr/event-metrics.csv；paired-effects.csv；acceptance.csv","run_experiment.py；recompute.py"])

if __name__=="__main__":
    build()
