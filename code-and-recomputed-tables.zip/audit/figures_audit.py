"""图形只读复算表和原固定截止证据，不运行模型，不改变任何统计值。"""
from pathlib import Path
from shutil import copytree,copy2
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

D=Path(__file__).resolve().parent
V=D.parent/'2026-11-21-项目总稿-v2'
F=D/'audit-figures'
F.mkdir(exist_ok=True)
for area in ('assets','revision-assets','quality-assets','rolling-figures','evidence'):
    copytree(V/area,D/area,dirs_exist_ok=True)
for name in ('数字追溯索引.csv','文献核验表.csv'):
    copy2(V/name,D/name)
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':10.5,
                     'pdf.fonttype':42,'axes.unicode_minus':False,
                     'axes.spines.top':False,'axes.spines.right':False})
conds=['clean','white40','white30','white20','ar30','jump']
labels=['干净','白噪声40','白噪声30','白噪声20','AR(1)30','突变']
names={'endpoint':'端点','quadratic':'二次拟合','ecgr':'ECGR','gate':'质量门控',
       'persistence':'持续性','gate_final_only':'仅末窗门控'}
colors={'endpoint':'#87944e','quadratic':'#b85d36','ecgr':'#4e7f9e','gate':'#674088',
        'persistence':'#226352','gate_final_only':'#676767'}
models=['ecgr','quadratic','endpoint']
def stacked(ax,frame,x,ticks,width):
    start=np.zeros(len(ticks))
    for m in models:
        values=100*frame[m].to_numpy()
        ax.bar(x,values,bottom=start,width=width,label=names[m],color=colors[m])
        start+=values
    ax.set(xticks=x,xticklabels=ticks,ylim=(0,103),yticks=[0,25,50,75,100])
    ax.grid(axis='y',alpha=.2)

# 固定截止图10保留可直接阅读的选择比例，高维云图在附录保留。
old=D/'evidence/nadir/quality-evidence/quality'
pred=pd.read_csv(old/'predictions.csv')
s=pred[pred.Kind.eq('single')]
a=s.groupby(['Condition','Selected']).size().unstack(fill_value=0)
a=a.reindex(index=conds,columns=models,fill_value=0); a=a.div(a.sum(axis=1),axis=0)
fig,ax=plt.subplots(figsize=(6.6,3.0),layout='constrained')
stacked(ax,a,np.arange(6),labels,.62)
ax.set_ylabel('选择比例 / %')
ax.legend(loc='upper center',bbox_to_anchor=(.5,1.21),ncol=3,frameon=False)
fig.savefig(F/'fixed-selection.pdf');plt.close(fig)

# 固定截止图11只在正文展示两类MAE。原六面板保留原来源及补充图引用。
met=pd.read_csv(old/'metrics.csv')
fig,axes=plt.subplots(1,2,figsize=(7.1,3.0),layout='constrained')
for ax,kind,heading in zip(axes,['single','pair'],['单事件最低频率','近端点配对差值']):
    b=met[met.Kind.eq(kind)].pivot(index='Condition',columns='Feature',values='MAE_mHz').loc[conds]
    for m in ['endpoint','quadratic','ecgr','gate']:
        ax.plot(np.arange(6),b[m],'-o',lw=1.2,ms=3,color=colors[m],label=names[m])
    ax.set(xticks=np.arange(6),xticklabels=['净','白40','白30','白20','相关','突变'],ylabel='MAE / mHz',title=heading)
    ax.grid(axis='y',alpha=.2)
legend,ls=axes[0].get_legend_handles_labels()
fig.legend(legend,ls,loc='outside upper center',ncol=4,frameon=False)
fig.savefig(F/'fixed-mae.pdf');plt.close(fig)

# 四窗选择是离散观测，每组最多四柱。完整原始比例由 MATLAB 输出。
choice=pd.read_csv(D/'复算表/逐窗选择比例.csv')
fig,axes=plt.subplots(2,3,figsize=(8.0,5.0),layout='constrained',sharey=True)
for ax,cond,lab in zip(axes.ravel(),conds,labels):
    b=choice[choice.Condition.eq(cond)].pivot(index='Window_s',columns='Selected',values='Fraction')
    b=b.reindex(index=[.2,.3,.4,.5],columns=models,fill_value=0).fillna(0)
    stacked(ax,b,np.arange(4),['0.20','0.30','0.40','0.50'],.62)
    ax.set_title(lab)
handles,n=axes[0,0].get_legend_handles_labels()
fig.legend(handles,n,loc='outside upper center',ncol=3,frameon=False)
fig.supxlabel('决策时刻 / s');fig.supylabel('选择比例 / %')
fig.savefig(F/'rolling-discrete-selection.pdf');plt.close(fig)

met=pd.read_csv(D/'复算表/全部绝对结果.csv')
view=met[(met.TargetFAR==.10)&met.Scope.eq('mixed')].set_index('Policy')
fig,ax=plt.subplots(figsize=(6.6,3.45),layout='constrained')
for m in ['gate','quadratic','persistence','endpoint','ecgr','gate_final_only']:
    q=view.loc[m]; ax.scatter(q.FARPct,q.HitRatePct,color=colors[m],label=names[m],s=48)
ax.axvline(10,color='.5',ls='--',lw=.8)
ax.set(xlabel='实际虚警率 / %',ylabel='及时命中率 / %')
ax.grid(alpha=.18)
ax.legend(loc='best',frameon=False,ncol=2,fontsize=9)
fig.savefig(F/'rolling-operating-points.pdf');plt.close(fig)
